package entity;

public class Search {

}
